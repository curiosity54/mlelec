Integrating atomistic ML models and electronic structure 
